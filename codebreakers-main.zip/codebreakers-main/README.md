# CodeBreakers

Our project is based on a remote health monitoring system which is comprised of 2 parts: one for the doctor side and the other for the patient side
