# tech stack
Python 3.12.3,
Dash with plotly,
dash-bootstrap python lib,
firebase ,
flask
