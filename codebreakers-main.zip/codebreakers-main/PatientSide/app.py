# import dash
# from dash import dcc, html
# from dash.dependencies import Input, Output, State
# import dash_bootstrap_components as dbc
# import paho.mqtt.client as mqtt
# from collections import deque
# import plotly.graph_objs as go
# import time
# from statistics import mode

# # MQTT broker details
# broker_address = "192.168.145.239"  # Replace with your MQTT broker address
# broker_port = 1883  # Default MQTT port
# topics = ["sensor/pulse", "sensor/temperature"]  # Topics to subscribe to

# # Initialize global variables for sensor data
# pulse_data = deque(maxlen=50)
# temperature_data = deque(maxlen=50)
# final_pulse_mode = None
# final_temperature_mode = None
# monitoring = True
# start_time = time.time()

# # Function to update sensor data
# def update_sensor_data(client, userdata, msg):
#     global pulse_data, temperature_data, final_pulse_mode, final_temperature_mode, monitoring, start_time
#     if not monitoring:
#         return

#     topic = msg.topic
#     payload = msg.payload.decode('utf-8')
#     if topic == "sensor/pulse":
#         pulse_data.append(int(payload))
#     elif topic == "sensor/temperature":
#         temperature_data.append(float(payload))
#     print(f"Received data: {topic} - {payload}")  # Debugging

#     # Stop monitoring after 30 seconds
#     if time.time() - start_time > 30:
#         monitoring = False
#         # Calculate mode for final values
#         if pulse_data:
#             final_pulse_mode = mode(pulse_data)
#         if temperature_data:
#             final_temperature_mode = mode(temperature_data)

# # MQTT client setup
# def on_connect(client, userdata, flags, rc):
#     if rc == 0:
#         print("Connected to MQTT Broker!")
#         for topic in topics:
#             client.subscribe(topic)
#     else:
#         print("Failed to connect, rc: ", rc)

# client = mqtt.Client()
# client.on_connect = on_connect
# client.on_message = update_sensor_data

# # Connect to MQTT broker
# client.connect(broker_address, broker_port)
# client.loop_start()

# # Dash app setup
# app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

# app.layout = dbc.Container([
#     dbc.Row([
#         dbc.Col(html.H1("Sensor Dashboard", style={'text-align': 'center', 'color': 'white'}), className="mb-4")
#     ], justify='center', style={'background-image': 'url("https://www.your-image-url.com/your-image.jpg")', 'background-size': 'cover'}),
#     dbc.Row([
#         dbc.Col(dcc.Graph(id='pulse-graph'), md=6),
#         dbc.Col(dcc.Graph(id='temperature-graph'), md=6)
#     ]),
#     dbc.Row([
#         dbc.Col(html.Div(id='final-pulse-value', style={'font-size': '24px', 'color': 'white'}), md=6),
#         dbc.Col(html.Div(id='final-temperature-value', style={'font-size': '24px', 'color': 'white'}), md=6)
#     ]),
#     dbc.Row([
#         dbc.Col(html.Div(id='timer', style={'font-size': '48px', 'text-align': 'center', 'color': 'white'}), className="mt-4", md=12)
#     ]),
#     dbc.Row([
#         dbc.Col([
#             dbc.Input(id="patient-name", placeholder="Enter Patient Name", type="text", className="mb-2"),
#             dbc.Input(id="patient-age", placeholder="Enter Patient Age", type="number", className="mb-2"),
#             dbc.Input(id="patient-info", placeholder="Enter Patient Info", type="text", className="mb-2"),
#         ], md=6)
#     ]),
#     html.Div(id='vitals', style={'display': 'none'}),
#     dcc.Interval(
#         id='interval-component',
#         interval=1*1000,  # in milliseconds (update every second)
#         n_intervals=0
#     )
# ], fluid=True, style={'background-color': '#2c3e50', 'padding': '20px'})

# @app.callback(
#     Output('pulse-graph', 'figure'),
#     [Input('interval-component', 'n_intervals')]
# )
# def update_pulse_graph(n):
#     global pulse_data
#     data = go.Scatter(
#         x=list(range(len(pulse_data))),
#         y=list(pulse_data),
#         mode='lines+markers'
#     )
#     layout = go.Layout(
#         title='Pulse Data',
#         xaxis=dict(title='Time'),
#         yaxis=dict(title='Pulse'),
#         paper_bgcolor='rgba(0,0,0,0)',
#         plot_bgcolor='rgba(0,0,0,0)',
#         font=dict(color='white')
#     )
#     return {'data': [data], 'layout': layout}

# @app.callback(
#     Output('temperature-graph', 'figure'),
#     [Input('interval-component', 'n_intervals')]
# )
# def update_temperature_graph(n):
#     global temperature_data
#     data = go.Scatter(
#         x=list(range(len(temperature_data))),
#         y=list(temperature_data),
#         mode='lines+markers'
#     )
#     layout = go.Layout(
#         title='Temperature Data',
#         xaxis=dict(title='Time'),
#         yaxis=dict(title='Temperature'),
#         paper_bgcolor='rgba(0,0,0,0)',
#         plot_bgcolor='rgba(0,0,0,0)',
#         font=dict(color='white')
#     )
#     return {'data': [data], 'layout': layout}

# @app.callback(
#     Output('final-pulse-value', 'children'),
#     [Input('interval-component', 'n_intervals')]
# )
# def display_final_pulse_value(n):
#     global final_pulse_mode, monitoring
#     if not monitoring:
#         return f"Pulse rate : {final_pulse_mode}"
#     return ""

# @app.callback(
#     Output('final-temperature-value', 'children'),
#     [Input('interval-component', 'n_intervals')]
# )
# def display_final_temperature_value(n):
#     global final_temperature_mode, monitoring
#     if not monitoring:
#         return f"Body Temperature : {final_temperature_mode}°C"
#     return ""

# @app.callback(
#     Output('timer', 'children'),
#     [Input('interval-component', 'n_intervals')]
# )
# def update_timer(n):
#     global start_time, monitoring
#     if monitoring:
#         remaining_time = max(0, 30 - int(time.time() - start_time))
#         return f"Time Remaining: {remaining_time} seconds"
#     return "Monitoring Complete"

# @app.callback(
#     Output('vitals', 'children'),
#     [Input('interval-component', 'n_intervals')],
#     [State('patient-name', 'value'),
#      State('patient-age', 'value'),
#      State('patient-info', 'value')]
# )
# def display_vitals(n, name, age, info):
#     global monitoring, final_pulse_mode, final_temperature_mode
#     if not monitoring:
#         return html.Div([
#             html.H3("Vitals", style={'color': 'white'}),
#             html.P(f"Name: {name}", style={'color': 'white'}),
#             html.P(f"Age: {age}", style={'color': 'white'}),
#             html.P(f"Info: {info}", style={'color': 'white'}),
#             html.P(f"Pulse Rate: {final_pulse_mode}", style={'color': 'white'}),
#             html.P(f"Body Temperature: {final_temperature_mode}°C", style={'color': 'white'}),
#         ], style={'background-color': '#34495e', 'padding': '20px', 'border-radius': '10px'})
#     return ""

# if __name__ == '__main__':
#     app.run_server(debug=True)
#     client.loop_stop()  # Stop the MQTT loop before exiting

# import dash
# from dash import dcc, html
# from dash.dependencies import Input, Output, State
# import dash_bootstrap_components as dbc
# import paho.mqtt.client as mqtt
# from collections import deque
# import plotly.graph_objs as go
# import time
# from statistics import mode
# import firebase_admin
# from firebase_admin import credentials, db

# # Initialize Firebase Admin SDK
# cred = credentials.Certificate(r"C:\Users\Neha P\Downloads\hackathon-3690b-firebase-adminsdk-n8epz-82235de100.json")
# firebase_admin.initialize_app(cred, {
#     'databaseURL': 'https://hackathon-3690b-default-rtdb.firebaseio.com/'
# })

# # MQTT broker details
# broker_address = "192.168.145.239"  # Replace with your MQTT broker address
# broker_port = 1883  # Default MQTT port
# topics = ["sensor/pulse", "sensor/temperature"]  # Topics to subscribe to

# # Initialize global variables for sensor data
# pulse_data = deque(maxlen=50)
# temperature_data = deque(maxlen=50)
# final_pulse_mode = None
# final_temperature_mode = None
# monitoring = True
# start_time = time.time()

# # Function to update sensor data
# def update_sensor_data(client, userdata, msg):
#     global pulse_data, temperature_data, final_pulse_mode, final_temperature_mode, monitoring, start_time
#     if not monitoring:
#         return

#     topic = msg.topic
#     payload = msg.payload.decode('utf-8')
#     if topic == "sensor/pulse":
#         pulse_data.append(int(payload))
#     elif topic == "sensor/temperature":
#         temperature_data.append(float(payload))
#     print(f"Received data: {topic} - {payload}")  # Debugging

#     # Stop monitoring after 30 seconds
#     if time.time() - start_time > 30:
#         monitoring = False
#         # Calculate mode for final values
#         if pulse_data:
#             final_pulse_mode = mode(pulse_data)
#         if temperature_data:
#             final_temperature_mode = mode(temperature_data)
#         # Save data to Firebase
#         save_to_firebase()

# # Function to save data to Firebase
# def save_to_firebase():
#     ref = db.reference('sensorData')
#     data = {
#         'final_pulse_mode': final_pulse_mode,
#         'final_temperature_mode': final_temperature_mode,
#         'timestamp': time.time()
#     }
#     ref.push(data)
#     print("Data saved to Firebase")

# # MQTT client setup
# def on_connect(client, userdata, flags, rc):
#     if rc == 0:
#         print("Connected to MQTT Broker!")
#         for topic in topics:
#             client.subscribe(topic)
#     else:
#         print("Failed to connect, rc: ", rc)

# client = mqtt.Client()
# client.on_connect = on_connect
# client.on_message = update_sensor_data

# # Connect to MQTT broker
# client.connect(broker_address, broker_port)
# client.loop_start()

# # Dash app setup
# app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

# app.layout = dbc.Container([
#     dbc.Row([
#         dbc.Col(html.H1("Sensor Dashboard", style={'text-align': 'center', 'color': 'white'}), className="mb-4")
#     ], justify='center', style={'background-image': 'url("https://www.your-image-url.com/your-image.jpg")', 'background-size': 'cover'}),
#     dbc.Row([
#         dbc.Col(dcc.Graph(id='pulse-graph'), md=6),
#         dbc.Col(dcc.Graph(id='temperature-graph'), md=6)
#     ]),
#     dbc.Row([
#         dbc.Col(html.Div(id='final-pulse-value', style={'font-size': '24px', 'color': 'white'}), md=6),
#         dbc.Col(html.Div(id='final-temperature-value', style={'font-size': '24px', 'color': 'white'}), md=6)
#     ]),
#     dbc.Row([
#         dbc.Col(html.Div(id='timer', style={'font-size': '48px', 'text-align': 'center', 'color': 'white'}), className="mt-4", md=12)
#     ]),
#     dbc.Row([
#         dbc.Col([
#             dbc.Input(id="patient-name", placeholder="Enter Patient Name", type="text", className="mb-2"),
#             dbc.Input(id="patient-age", placeholder="Enter Patient Age", type="number", className="mb-2"),
#             dbc.Input(id="patient-info", placeholder="Enter Patient Info", type="text", className="mb-2"),
#             dbc.Button("Save Vitals", id="save-vitals-button", color="primary", className="mt-2"),
#             dbc.Button("Restart Monitoring", id="restart-button", color="warning", className="mt-3")
#         ], md=6)
#     ]),
#     html.Div(id='vitals', style={'display': 'none'}),
#     dcc.Interval(
#         id='interval-component',
#         interval=1*1000,  # in milliseconds (update every second)
#         n_intervals=0
#     )
# ], fluid=True, style={'background-color': '#2c3e50', 'padding': '20px'})

# @app.callback(
#     Output('pulse-graph', 'figure'),
#     [Input('interval-component', 'n_intervals')]
# )
# def update_pulse_graph(n):
#     global pulse_data
#     data = go.Scatter(
#         x=list(range(len(pulse_data))),
#         y=list(pulse_data),
#         mode='lines+markers'
#     )
#     layout = go.Layout(
#         title='Pulse Data',
#         xaxis=dict(title='Time'),
#         yaxis=dict(title='Pulse'),
#         paper_bgcolor='rgba(0,0,0,0)',
#         plot_bgcolor='rgba(0,0,0,0)',
#         font=dict(color='white')
#     )
#     return {'data': [data], 'layout': layout}

# @app.callback(
#     Output('temperature-graph', 'figure'),
#     [Input('interval-component', 'n_intervals')]
# )
# def update_temperature_graph(n):
#     global temperature_data
#     data = go.Scatter(
#         x=list(range(len(temperature_data))),
#         y=list(temperature_data),
#         mode='lines+markers'
#     )
#     layout = go.Layout(
#         title='Temperature Data',
#         xaxis=dict(title='Time'),
#         yaxis=dict(title='Temperature'),
#         paper_bgcolor='rgba(0,0,0,0)',
#         plot_bgcolor='rgba(0,0,0,0)',
#         font=dict(color='white')
#     )
#     return {'data': [data], 'layout': layout}

# @app.callback(
#     Output('final-pulse-value', 'children'),
#     [Input('interval-component', 'n_intervals')]
# )
# def display_final_pulse_value(n):
#     global final_pulse_mode, monitoring
#     if not monitoring:
#         return f"Pulse rate : {final_pulse_mode}"
#     return ""

# @app.callback(
#     Output('final-temperature-value', 'children'),
#     [Input('interval-component', 'n_intervals')]
# )
# def display_final_temperature_value(n):
#     global final_temperature_mode, monitoring
#     if not monitoring:
#         return f"Body Temperature : {final_temperature_mode}°C"
#     return ""

# @app.callback(
#     Output('timer', 'children'),
#     [Input('interval-component', 'n_intervals')]
# )
# def update_timer(n):
#     global start_time, monitoring
#     if monitoring:
#         remaining_time = max(0, 30 - int(time.time() - start_time))
#         return f"Time Remaining: {remaining_time} seconds"
#     return "Monitoring Complete"

# @app.callback(
#     Output('vitals', 'children'),
#     [Input('save-vitals-button', 'n_clicks')],
#     [State('patient-name', 'value'),
#      State('patient-age', 'value'),
#      State('patient-info', 'value')]
# )
# def save_vitals_to_firebase(n_clicks, name, age, info):
#     global monitoring, final_pulse_mode, final_temperature_mode
#     if not monitoring:
#         ref = db.reference('vitals')
#         data = {
#             'patient_name': name,
#             'patient_age': age,
#             'patient_info': info,
#             'final_pulse_mode': final_pulse_mode,
#             'final_temperature_mode': final_temperature_mode,
#             'timestamp': time.time()
#         }
#         ref.push(data)
#         print("Vitals saved to Firebase")
#         return dbc.Alert("Vitals saved successfully!", color="success")
#     return ""

# @app.callback(
#     Output('interval-component', 'disabled'),
#     [Input('restart-button', 'n_clicks')]
# )
# def restart_monitoring(n_clicks):
#     global monitoring, pulse_data, temperature_data, final_pulse_mode, final_temperature_mode, start_time
#     monitoring = True
#     pulse_data.clear()
#     temperature_data.clear()
#     final_pulse_mode = None
#     final_temperature_mode = None
#     start_time = time.time()
#     return False

# if __name__ == '__main__':
#     app.run_server(debug=True)
#     client.loop_stop()  # Stop the MQTT loop before exiting


import dash
from dash import dcc, html
from dash.dependencies import Input, Output, State
import dash_bootstrap_components as dbc
import paho.mqtt.client as mqtt
from collections import deque
import plotly.graph_objs as go
import time
from statistics import mode
import firebase_admin
from firebase_admin import credentials, db

# Initialize Firebase Admin SDK
cred = credentials.Certificate(r"C:\Users\Neha P\Downloads\hackathon-3690b-firebase-adminsdk-n8epz-82235de100.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://hackathon-3690b-default-rtdb.firebaseio.com/'
})

# MQTT broker details
broker_address = "192.168.145.239"  # Replace with your MQTT broker address
broker_port = 1883  # Default MQTT port
topics = ["sensor/pulse", "sensor/temperature"]  # Topics to subscribe to

# Initialize global variables for sensor data
pulse_data = deque(maxlen=50)
temperature_data = deque(maxlen=50)
final_pulse_mode = None
final_temperature_mode = None
monitoring = True
start_time = time.time()

# Function to update sensor data
def update_sensor_data(client, userdata, msg):
    global pulse_data, temperature_data, final_pulse_mode, final_temperature_mode, monitoring, start_time
    if not monitoring:
        return

    topic = msg.topic
    payload = msg.payload.decode('utf-8')
    if topic == "sensor/pulse":
        pulse_data.append(int(payload))
    elif topic == "sensor/temperature":
        temperature_data.append(float(payload))
    print(f"Received data: {topic} - {payload}")  # Debugging

    # Stop monitoring after 30 seconds
    if time.time() - start_time > 30:
        monitoring = False
        # Calculate mode for final values
        if pulse_data:
            final_pulse_mode = mode(pulse_data)
        if temperature_data:
            final_temperature_mode = mode(temperature_data)

# MQTT client setup
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected to MQTT Broker!")
        for topic in topics:
            client.subscribe(topic)
    else:
        print("Failed to connect, rc: ", rc)

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = update_sensor_data

# Connect to MQTT broker
client.connect(broker_address, broker_port)
client.loop_start()

# Dash app setup
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

app.layout = dbc.Container([
    dbc.Row([
        dbc.Col(html.H1("Sensor Dashboard", style={'text-align': 'center', 'color': 'white'}), className="mb-4")
    ], justify='center', style={'background-image': 'url("https://www.your-image-url.com/your-image.jpg")', 'background-size': 'cover'}),
    dbc.Row([
        dbc.Col(dcc.Graph(id='pulse-graph'), md=6),
        dbc.Col(dcc.Graph(id='temperature-graph'), md=6)
    ]),
    dbc.Row([
        dbc.Col(html.Div(id='final-pulse-value', style={'font-size': '24px', 'color': 'white'}), md=6),
        dbc.Col(html.Div(id='final-temperature-value', style={'font-size': '24px', 'color': 'white'}), md=6)
    ]),
    dbc.Row([
        dbc.Col(html.Div(id='timer', style={'font-size': '48px', 'text-align': 'center', 'color': 'white'}), className="mt-4", md=12)
    ]),
    dbc.Row([
        dbc.Col([
            dbc.Input(id="patient-name", placeholder="Enter Patient Name", type="text", className="mb-2"),
            dbc.Input(id="patient-age", placeholder="Enter Patient Age", type="number", className="mb-2"),
            dbc.Input(id="patient-info", placeholder="Enter Patient Info", type="text", className="mb-2"),
            dbc.Button("Save Vitals", id="save-vitals-button", color="primary", className="mt-2"),
            dbc.Button("Restart Monitoring", id="restart-button", color="warning", className="mt-3")
        ], md=6)
    ]),
    html.Div(id='vitals', style={'display': 'none'}),
    dcc.Interval(
        id='interval-component',
        interval=1*1000,  # in milliseconds (update every second)
        n_intervals=0
    )
], fluid=True, style={'background-color': '#2c3e50', 'padding': '20px'})

@app.callback(
    Output('pulse-graph', 'figure'),
    [Input('interval-component', 'n_intervals')]
)
def update_pulse_graph(n):
    global pulse_data
    data = go.Scatter(
        x=list(range(len(pulse_data))),
        y=list(pulse_data),
        mode='lines+markers'
    )
    layout = go.Layout(
        title='Pulse Data',
        xaxis=dict(title='Time'),
        yaxis=dict(title='Pulse'),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        font=dict(color='white')
    )
    return {'data': [data], 'layout': layout}

@app.callback(
    Output('temperature-graph', 'figure'),
    [Input('interval-component', 'n_intervals')]
)
def update_temperature_graph(n):
    global temperature_data
    data = go.Scatter(
        x=list(range(len(temperature_data))),
        y=list(temperature_data),
        mode='lines+markers'
    )
    layout = go.Layout(
        title='Temperature Data',
        xaxis=dict(title='Time'),
        yaxis=dict(title='Temperature'),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        font=dict(color='white')
    )
    return {'data': [data], 'layout': layout}

@app.callback(
    Output('final-pulse-value', 'children'),
    [Input('interval-component', 'n_intervals')]
)
def display_final_pulse_value(n):
    global final_pulse_mode, monitoring
    if not monitoring:
        return f"Pulse rate : {final_pulse_mode}"
    return ""

@app.callback(
    Output('final-temperature-value', 'children'),
    [Input('interval-component', 'n_intervals')]
)
def display_final_temperature_value(n):
    global final_temperature_mode, monitoring
    if not monitoring:
        return f"Body Temperature : {final_temperature_mode}°C"
    return ""

@app.callback(
    Output('timer', 'children'),
    [Input('interval-component', 'n_intervals')]
)
def update_timer(n):
    global start_time, monitoring
    if monitoring:
        remaining_time = max(0, 30 - int(time.time() - start_time))
        return f"Time Remaining: {remaining_time} seconds"
    return "Monitoring Complete"

@app.callback(
    Output('vitals', 'children'),
    [Input('save-vitals-button', 'n_clicks')],
    [State('patient-name', 'value'),
     State('patient-age', 'value'),
     State('patient-info', 'value')]
)
def save_vitals_to_firebase(n_clicks, name, age, info):
    global monitoring, final_pulse_mode, final_temperature_mode
    if not monitoring:
        ref = db.reference('vitals')
        data = {
            'patient_name': name,
            'patient_age': age,
            'patient_info': info,
            'final_pulse_mode': final_pulse_mode,
            'final_temperature_mode': final_temperature_mode,
            'timestamp': time.time()
        }
        ref.push(data)
        print("Vitals saved to Firebase")
        return dbc.Alert("Vitals saved successfully!", color="success")
    return ""

@app.callback(
    Output('interval-component', 'disabled'),
    [Input('restart-button', 'n_clicks')]
)
def restart_monitoring(n_clicks):
    global monitoring, pulse_data, temperature_data, final_pulse_mode, final_temperature_mode, start_time
    monitoring = True
    pulse_data.clear()
    temperature_data.clear()
    final_pulse_mode = None
    final_temperature_mode = None
    start_time = time.time()
    return False

if __name__ == '__main__':
    app.run_server(debug=True)
    client.loop_stop()  # Stop the MQTT loop before exiting
