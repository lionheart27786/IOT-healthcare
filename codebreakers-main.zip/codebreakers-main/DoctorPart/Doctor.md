DOCTOR PART
This folder contains all the code we have used for the doctor part in our project, the file names are suggestive enough to understand the code within it
