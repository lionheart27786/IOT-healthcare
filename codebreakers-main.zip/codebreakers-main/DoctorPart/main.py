import streamlit as st
from streamlit_option_menu import option_menu
import os
from dotenv import load_dotenv
import home, your, account, chat

# Load environment variables
load_dotenv()

# Set page configuration
st.set_page_config(page_title="IOT-Healthcare")

# Add Google Analytics tracking
st.markdown(
    f"""
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id={os.getenv('analytics_tag')}"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){{dataLayer.push(arguments);}}
        gtag('js', new Date());
        gtag('config', '{os.getenv('analytics_tag')}');
    </script>
    """, unsafe_allow_html=True
)

print(os.getenv('analytics_tag'))

class MultiApp:
    def __init__(self):
        self.apps = []

    def add_app(self, title, func):
        self.apps.append({"title": title, "function": func})

    def run(self):
        with st.sidebar:
            app = option_menu(
                menu_title='IOT-Healthcare',
                options=['Doctor Forum', 'Account', 'Patient Registry', 'Assistant','Credits'],
                icons=['hospital', 'person-badge', 'clipboard-data', 'chat-text-fill','💰'],
                menu_icon='cast',
                default_index=1,
                styles={
                    "container": {"padding": "5!important", "background-color": 'black'},
                    "icon": {"color": "white", "font-size": "23px"},
                    "nav-link": {"color": "white", "font-size": "20px", "text-align": "left", "margin": "0px", "--hover-color": "blue"},
                    "nav-link-selected": {"background-color": "#02ab21"},
                }
            )

        if app == "Doctor Forum":
            home.app()
        elif app == "Account":
            account.app()
        elif app == "Patient Registry":
            your.app()
        elif app == "Assistant":
            chat.app()
        elif app == "Credits":
            credits.app()

# Instantiate and run the app
app = MultiApp()
app.run()
