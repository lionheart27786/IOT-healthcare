from dotenv import load_dotenv
load_dotenv() ## loading all the environment variables

import streamlit as st
import os
import google.generativeai as genai


def app():
    genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

# Function to load Gemini Pro model and get responses
    def get_gemini_response(question):
        model = genai.GenerativeModel("gemini-pro")
        chat = model.start_chat(history=[])
        response = chat.send_message(question, stream=True)
        return response

# Initialize Streamlit app
    st.header("Medical Assistant")

# Input field and submit button
    input = st.text_input("Input: ", key="input")
    submit = st.button("Give response !!")

    if submit and input:
        response = get_gemini_response(input)
        st.subheader("Here is the response you asked for!!! Let me know if any changes required.....")
        for chunk in response:
            st.write(chunk.text)



    
