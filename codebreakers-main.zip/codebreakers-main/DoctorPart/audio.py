import streamlit as st
import speech_recognition as sr
from googletrans import Translator

def app():
    st.title("Speech Recognition and Translation")
    
    # Initialize the recognizer and translator
    recognizer = sr.Recognizer()
    translator = Translator()
    
    if st.button("Start Listening"):
        st.write("Please speak now")
        
        # Use the microphone as input source
        with sr.Microphone() as inputs:
            try:
                # Listen for the first phrase and extract it into audio data
                listening = recognizer.listen(inputs)
                st.write("Analyzing...")
                
                # Recognize speech using Google Web Speech API
                recognized_text = recognizer.recognize_google(listening, language="kn-IN")
                st.write("Did you say (Kannada): " + recognized_text)
                
                # Translate recognized text to English
                translated_text = translator.translate(recognized_text, src='kn', dest='en').text
                st.write("In English: " + translated_text)
            except sr.UnknownValueError:
                # Catching when the speech is unintelligible
                st.write("Could not understand the audio, please speak again")
            except sr.RequestError as e:
                # Catching errors related to the API request
                st.write(f"Could not request results; {e}")


