import streamlit as st
import firebase_admin
from firebase_admin import credentials, firestore
import plotly.graph_objects as go






# Initialize Firebase Admin SDK (ensure to replace 'path/to/your/serviceAccountKey.json' with your key file)
if not firebase_admin._apps:
    #cred = credentials.Certificate('iot-healthcare-6cddb-8d334f64bbc8.json')
    firebase_admin.initialize_app(cred)

def app():
    # Initialize Firestore client
    db = firestore.client()
    st.session_state.db = db

    # Title of the app
    st.title('IOT Healthcare - Credits')

    # Placeholder for login message
    if 'username' not in st.session_state:
        st.session_state.username = ''

    if st.session_state.username == '':
        ph = 'Login to be able to post!!'
        st.write(ph)
    else:
        # Display user's credits
        doc_ref = db.collection('Posts').document('Demo').collection('Credits').document(st.session_state.username)
        doc = doc_ref.get()

        if doc.exists:
            credits = doc.to_dict().get('credits', 0)
        else:
            credits = 0
            doc_ref.set({'credits': credits})

        st.write(f"Current credits: {credits}")

        # Increment credits on button click
        if st.button('Increment Credits'):
            credits += 1
            doc_ref.update({'credits': credits})
            st.write(f"Updated credits: {credits}")

        # # Gauge plot
        # fig = go.Figure(go.Indicator(
        #     mode="gauge+number",
        #     value=credits,
        #     title={'text': "Credits"},
        #     gauge={
        #         'axis': {'range': [0, 100]},  # Adjust the range according to your needs
        #         'bar': {'color': "darkblue"},
        #         'steps': [
        #             {'range': [0, 50], 'color': "lightgray"},
        #             {'range': [50, 100], 'color': "gray"}],
        #         'threshold': {'line': {'color': "red", 'width': 4}, 'thickness': 0.75, 'value': credits}
        #     }
        # ))

        # st.plotly_chart(fig)


